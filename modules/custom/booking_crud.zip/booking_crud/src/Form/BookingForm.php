<?php
// (The full BookingForm.php code from previous response goes here)