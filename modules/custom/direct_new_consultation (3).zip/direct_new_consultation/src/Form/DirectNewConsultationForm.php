<?php

namespace Drupal\direct_new_consultation\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Render\Markup;
use Drupal\Core\Url;
use Drupal\node\Entity\Node;

/**
 * Builds Direct Consultation form.
 */
class DirectNewConsultationForm extends FormBase {

  public function getFormId() {
    return 'direct_new_consultation_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {

    // Attach library for auto-scroll
    $form['#attached']['library'][] = 'direct_new_consultation/scroll_confirm';

    // Fetch nodes of content type "health_concern"
    $nodes = \Drupal::entityTypeManager()->getStorage('node')->loadByProperties(['type' => 'health_concern']);
    $options = [];

    foreach ($nodes as $node) {
      $term_entity = $node->get('field_health_concern_name')->entity;
      $speciality = $term_entity ? $term_entity->label() : 'Unknown';
      $fees = $node->get('field_consultant_fees')->value ?? 'N/A';
      $options[$node->id()] = [
        'speciality' => $speciality,
        'fees' => $fees,
      ];
    }

    // Build HTML markup
    $html = '<div id="book-visit-container" class="p-4 mt shadow-sm">
      <div class="row">
        <div class="col-md-6 flow-form-left">
          <div class="p-1 rounded-3 bg-white position-relative">
            <h4 class="book-visit-title mb-3">Consult with a Doctor</h4>';

    if (!empty($options)) {
      foreach ($options as $nid => $data) {
        $html .= '
          <div class="mb-3">
            <label class="form-label fw-semibold">Speciality</label>
            <div class="speciality-box border rounded-2 p-2 d-inline-block bg-light-subtle" 
                 style="min-width:220px; cursor:pointer;">
              <div class="form-check">
                <input 
                  class="form-check-input" 
                  type="radio" 
                  name="speciality" 
                  id="speciality_' . $nid . '" 
                  value="' . $nid . '" required>
                <label class="form-check-label fw-semibold" for="speciality_' . $nid . '">
                  ' . $data['speciality'] . '
                  <span class="badge bg-light text-dark ms-2">' . $data['fees'] . '</span>
                </label>
              </div>
            </div>
          </div>';
      }
    }
    else {
      $html .= '<p>No health concerns found.</p>';
    }

    $html .= '
          <div class="mb-3">
            <label class="form-label fw-semibold" for="edit-name">Patient Name</label>
            <input type="text" id="edit-name" name="name" class="form-control"
                   placeholder="Enter patient name for prescriptions" required>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold" for="edit-phone">Mobile number</label>
            <div class="input-group">
              <span class="input-group-text bg-white border-end-0">
                <img src="https://flagcdn.com/w20/in.png" alt="IN" width="20" height="14" style="border-radius:2px;">
              </span>
              <input type="text" id="edit-phone" name="phone" class="form-control border-start-0"
                     placeholder="Enter mobile number" maxlength="10" required>
            </div>
            <small class="form-text text-muted">A verification code will be sent to this number.</small>
          </div>

          <div class="mt-3">
            <button type="submit" id="edit-submit" class="btn btn-primary">Continue</button>
          </div>
        </div>

        <div class="col-md-6 mt-5">
          <div class="guiding-slider">
            <div class="guiding-slide">
              <img src="https://www.practo.com/consult/bundles/cwipage/images/qualified_doctors.png" alt="Verified Doctors">
              <h4>Verified Doctors</h4>
            </div>
            <div class="guiding-slide">
              <img src="https://www.practo.com/consult/bundles/cwipage/images/ic-security-v1.png" alt="Private & Secure">
              <h4>Private &amp; Secure</h4>
            </div>
            <div class="guiding-slide">
              <img src="https://www.practo.com/consult/bundles/cwipage/images/ic-chats-v1.png" alt="Free Follow-up">
              <h4>Free Follow-up</h4>
            </div>
          </div>
        </div>

      </div>
    </div>';

    $form['layout'] = [
      '#type' => 'markup',
      '#markup' => Markup::create($html),
      '#allowed_tags' => ['div','h4','label','input','span','small','button','img','style','p','form','h3','h5'],
    ];

    return $form;
  }

  public function validateForm(array &$form, FormStateInterface $form_state) {
    $phone = $form_state->getValue('phone');
    if (!empty($phone) && !preg_match('/^[0-9]{10}$/', $phone)) {
      $form_state->setErrorByName('phone', $this->t('Please enter a valid 10-digit phone number.'));
    }
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $name = $form_state->getValue('name');
    $phone = $form_state->getValue('phone');
    $speciality_id = $form_state->getValue('speciality');

    $node = Node::load($speciality_id);
    $speciality_name = $node ? ($node->get('field_health_concern_name')->entity ? $node->get('field_health_concern_name')->entity->label() : 'Unknown') : 'Unknown';
    $fees = $node ? $node->get('field_consultant_fees')->value : 'N/A';

    \Drupal::messenger()->addMessage($this->t('Thank you @name, your @speciality consultation (fees @fees) has been confirmed.', [
      '@name' => $name,
      '@speciality' => $speciality_name,
      '@fees' => $fees,
    ]));

    // Log WhatsApp message locally
    \Drupal::logger('direct_new_consultation')->info('WhatsApp message to {phone}: {msg}', ['phone' => $phone, 'msg' => "Hello $name, your booking for $speciality_name consultation (Fees: $fees) is confirmed!"]);

    // Attempt to send via WhatsApp Cloud API if credentials provided.
    $this->sendWhatsAppMessage($phone, "Hello $name, your booking for $speciality_name consultation (Fees: $fees) is confirmed!");
  }

  private function sendWhatsAppMessage($phone, $message) {
    // Replace with your credentials
    $access_token = 'YOUR_ACCESS_TOKEN_HERE';
    $phone_number_id = 'YOUR_PHONE_NUMBER_ID_HERE';

    if ($access_token === 'YOUR_ACCESS_TOKEN_HERE' || $phone_number_id === 'YOUR_PHONE_NUMBER_ID_HERE') {
      // Credentials not set - skip sending.
      \Drupal::logger('direct_new_consultation')->notice('WhatsApp Cloud API credentials not set. Skipping send.');
      return;
    }

    $url = "https://graph.facebook.com/v17.0/$phone_number_id/messages";
    $payload = [
      'messaging_product' => 'whatsapp',
      'to' => '91' . preg_replace('/\D+/', '', $phone),
      'type' => 'text',
      'text' => ['body' => $message],
    ];

    try {
      $options = [
        'http' => [
          'method'  => 'POST',
          'header'  => "Content-Type: application/json\r\nAuthorization: Bearer $access_token\r\n",
          'content' => json_encode($payload),
          'timeout' => 10,
        ],
      ];
      $context  = stream_context_create($options);
      $result = @file_get_contents($url, false, $context);
      \Drupal::logger('direct_new_consultation')->info('WhatsApp Cloud API response: ' . ($result ?? 'no-response'));
    }
    catch (\Exception $e) {
      \Drupal::logger('direct_new_consultation')->error('WhatsApp send error: ' . $e->getMessage());
    }
  }

}
