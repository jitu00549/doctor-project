<?php
// (The full BookingController.php code from previous response goes here)