<?php 

namespace Drupal\book_visit_form\Controller;

use Drupal\Core\Controller\ControllerBase;

class ThankYouController extends ControllerBase {
  public function content() {
    return [
      '#markup' => $this->t('<h2>Thank you! Your appointment has been booked successfully.</h2>'),
    ];
  }
}


?>